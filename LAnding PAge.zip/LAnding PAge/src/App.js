import logo from './logo.svg';
import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import { Carousel,NavDropdown,Nav,Navbar } from 'react-bootstrap';
//import ./orpnaChennai/birthday-2.jpg;

function App() {
  return (
    <div >
        <FrontPage/>
    </div>
  );
}

function FrontPage(){
  return(
    <div >
        <Header/>
        <MiddleSection/>
        <Footer/>
    </div>
  );
}

function Header(){
  return(
    // <div className="container-fluid ">
    //   <div className="row border border-secondary border-top-0" style={{height:" 5%"}}>
    //     <div className="col-2  d-flex justify-content-center align-items-center"style={{fontFamily: "'Sofia', sans-serif",fontSize:" 5 vw"}}><h1><b>Karn</b></h1></div>

    //     <div className="col-8  d-flex justify-content-start align-items-center">
    //     <div className="col" style={{fontSize:" 5 vw"}} ><a href="#">Home</a></div>
    //     <div className="col" style={{fontSize:" 5 vw"}}><a href="#">Ajun ek page</a></div>
    //     <div className="col" style={{fontSize:" 5 vw"}}><a href="#">PAge 2</a></div>
    //     <div className="col" style={{fontSize:" 5 vw"}}><a href="#">About US</a></div>
    //     </div>
      

    //     <div className="col-2 d-flex justify-content-around align-items-center"><a href="#">Login/Register</a></div>

    //   </div>
    // </div>




            <Navbar collapseOnSelect expand="lg" bg="light" variant="light">
          <Navbar.Brand href="#home">KARN</Navbar.Brand>
          <Navbar.Toggle aria-controls="responsive-navbar-nav" />
          <Navbar.Collapse id="responsive-navbar-nav">
            <Nav className="mr-auto">
              <Nav.Link href="#features">ABCD</Nav.Link>
              <Nav.Link href="#pricing">EFGH</Nav.Link>
              <NavDropdown title="Dropdown" id="collasible-nav-dropdown">
                <NavDropdown.Item href="#action/3.1">Action</NavDropdown.Item>
                <NavDropdown.Item href="#action/3.2">Another action</NavDropdown.Item>
                <NavDropdown.Item href="#action/3.3">Something</NavDropdown.Item>
                <NavDropdown.Divider />
                <NavDropdown.Item href="#action/3.4">Separated link</NavDropdown.Item>
              </NavDropdown>
            </Nav>
            <Nav>
              <Nav.Link href="#deets">LOGIN/SignUp</Nav.Link>
      {/* <Nav.Link eventKey={2} href="#memes">
        Dank memes
      </Nav.Link> */}
    </Nav>
  </Navbar.Collapse>
</Navbar>
  );
}

function MiddleSection(){
  return(
    <div className="container-fluid" style={{background:"#F3F8FA",margin: "0% 0% 1% 0%"}}>
      <div className="row" style={{height:600}}>
      <div className="col-9 border border-1  rounded" style={{padding:"1%"}}>
      <div style={{margin: "0% 0% 0% 0%"}}>
      <Carousel >
          <Carousel.Item>
            <img
              src="https://i.pinimg.com/originals/b3/99/63/b39963256b5008922c1de3018396c188.jpg"
              className="d-block w-100"
              alt="First slide"
              width="10px"
              height="450px"
            />
            <Carousel.Caption>
              {/* <h3>First slide label</h3> */}
              {/* <p>Nulla vitae elit libero, a pharetra augue mollis interdum.</p> */}
            </Carousel.Caption>
          </Carousel.Item>
          <Carousel.Item>
            <img
              className="d-block w-100"
              src="https://i.pinimg.com/originals/b3/99/63/b39963256b5008922c1de3018396c188.jpg"
              alt="Second slide"
              width="10px"
              height="450px"
            />
        
            <Carousel.Caption>
              {/* <h3>Second slide label</h3> */}
              {/* <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p> */}
            </Carousel.Caption>
          </Carousel.Item>
          <Carousel.Item>
            <img
              className="d-block w-100"
              src="https://i.pinimg.com/originals/b3/99/63/b39963256b5008922c1de3018396c188.jpg"
              alt="Third slide"
              width="10px"
              height="450px"
            />
        
            <Carousel.Caption>
              {/* <h3>Third slide label</h3> */}
              {/* <p>Praesent commodo cursus magna, vel scelerisque nisl consectetur.</p> */}
            </Carousel.Caption>
          </Carousel.Item>
        </Carousel>
      </div>
      </div>
      <div className="col-3 d-flex justify-content-center align-items-center column border border-1  rounded" >
     
        <form>
          {/* <div className=""> */}
          <div className=" ">
          <div class="form-group d-flex flex-column bd-highlight mb-3">
            <input type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="OK"/>
          </div>
          <div class="form-group d-flex flex-column bd-highlight mb-3">
            <input type="text" class="form-control" id="exampleInputEmail1" placeholder="ok"/>
          </div>
          <div class="form-group d-flex flex-column bd-highlight mb-3">
          <input type="text" class="form-control" id="exampleInputEmail1" placeholder="ok"/>
          </div><br/>
          <div class="form-group d-flex flex-column bd-highlight mb-3">
          <button type="submit" class="btn btn-primary">Search</button>
          </div>
          </div>
          {/* </div> */}
        </form>

      </div>
      </div>
    </div>    
  );
}


function Footer(){
  return(
    // <div className="container-fluid">
    //   <div className="row border border-secondary border-top-0 border-bottom-0" style={{height:"10vh",background:"red"}}>
    //     <div className="col d-flex justify-content-center align-items-center "><a href="#">Contact Us</a></div>
    //     <div className="col d-flex justify-content-center align-items-center "><a href="#">About Us</a></div>

    //   </div>
    // </div>


        <Nav className="justify-content-center" activeKey="/home">
        <Nav.Item>
          <Nav.Link eventKey="link-1">Contact Us</Nav.Link>
        </Nav.Item>
        <Nav.Item>
          <Nav.Link eventKey="link-2">ABOUT US</Nav.Link>
        </Nav.Item>
      </Nav>

  );

}



export default App;
